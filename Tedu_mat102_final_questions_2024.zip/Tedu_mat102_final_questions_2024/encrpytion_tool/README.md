TED University Math 102 Final Exam file

The file is encrpyted for security reasons.
To start decryption, run 'sudo chmod +x start_decryption.sh && ./start_decryption.sh'