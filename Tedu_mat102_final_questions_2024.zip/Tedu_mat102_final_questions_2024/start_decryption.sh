#!/bin/bash
cd encrpytion_toold
sudo apt-get install -y python3
python3 -m venv venv
source venv/bin/activate